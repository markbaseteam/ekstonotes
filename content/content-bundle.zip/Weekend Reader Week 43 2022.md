---
dg-home: false
dg-publish: true
dg-show-backlinks: true
dg-show-local-graph: true
dg-show-inline-title: true
---
---

![[Pasted image 20221026201315.png]]
 

**Cross-Tenant OneDrive Migration**
Microsoft is looking after companies that have the need to migrate OneDrive content from one tenant to another. Perfect, as cloud adoption has definitely created some need for that functionality - [Read](https://learn.microsoft.com/en-gb/microsoft-365/enterprise/cross-tenant-onedrive-migration?view=o365-worldwide)

**Cybersecurity is for everyone—this October and all year**
Little summary of what Microsoft offers for this years *Cybersecurity Awareness Month*. This mainly links to Microsoft learning paths, of which I am a big fan - [Read](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/cybersecurity-is-for-everyone-this-october-and-all-year/ba-p/2319502#)

**What’s new in Security and Management in SharePoint, OneDrive, and Teams – Microsoft Ignite 2022**
Post Ignite is a great time to go through different posts collecting news specific per product. Here we have a summary of Security and Management related announcements for Teams, SharePoint online and OneDrive - [Read](https://techcommunity.microsoft.com/t5/microsoft-sharepoint-blog/what-s-new-in-security-and-management-in-sharepoint-onedrive-and/ba-p/3648912)

**macOS Management with Intune – Part III**
A rundown of settings that can be set for managed Macs in companies. Be sure to [to visit the other posts in the series](https://intuneirl.com/category/macos/) as well - [Read](https://intuneirl.com/2022/10/macos-management-with-intune-part-iii/)

**The Microsoft Purview Data Loss Prevention Ninja Training is here! - Microsoft Community Hub**
Ninja alert! This time for those Purview DLP afficianados out there - [Read](https://techcommunity.microsoft.com/t5/security-compliance-and-identity/the-microsoft-purview-data-loss-prevention-ninja-training-is/ba-p/3659015)

**Multicloud Security Posture Management**
Interactive guide that shows the offering of Microsoft Defender for Cloud, especially referring to its multi-cloud capabilities for GCP and AWS. Cool - [Read](https://mslearn.cloudguides.com/guides/Defender%20for%20Cloud)

**Move Intune Objects from Development to Production**
Jannik Reinhard shows his approach to move Intune objects through different stages - [Read](https://jannikreinhard.com/2022/10/23/intune-devops-tools-move-objects-from-dev-to-prod-tenant/)

**5 hidden gems from Microsoft Ignite 2022**
Mark Kashman dug up some hidden gems in the Ignite Book of News - or wherever one finds gems nowadays - some shiny stones - I dread the organisational messages on Windows, though. Organisations and I don't seem to agree what is important in my day-to-day - [Read](https://kashbox.substack.com/p/5-hidden-gems-from-microsoft-ignite)

**Vendor Agnostic Zero Trust Whitepaper**
Isaca - best known for its Security Certifications, delivers a whitepaper to outline their understanding and guidance on Zero Trust - [Read](https://store.isaca.org/s/#/store/browse/detail/a2S4w000005DtLZEA0)

**Security: How to achieve a Microsoft Secure Score for Devices above 95% in Microsoft Defender for Endpoint with Microsoft Intune**
Fabrizio Gobeli shows us how to achieve a Secure Score that is definitely higher than *Organizations of a similar size* - You now have no excuses anymore. Except, maybe, productive users and some legacy - [Read](https://gobisweb.ch/2022/10/07/security-how-to-achieve-a-microsoft-secure-score-for-devices-above-95-in-microsoft-defender-for-endpoint-with-microsoft-intune/)

**My Top 10 Takeaways from Microsoft Ignite 2022**
While we are on the topic of digging up gems, Fabrizio also shared his Top 10 takeaways and he didn't even make me click through a listicle - proper oldschool-pre-monetizing-blogging right there - [Read](https://gobisweb.ch/2022/10/15/news-my-top-10-takeaways-from-microsoft-ignite-2022/)


And that is that for that Weekend Reader